/*:
 * @plugindesc クイズ用プラグイン。
 * @author くろうど（kuroudo119）
 * @help
 * KRD_Quiz.js
 * (c) 2021 kuroudo119
 * 
 * このプラグインはMITライセンスです。
 * https://github.com/kuroudo119/RPGMV-Plugin/blob/master/LICENSE
 * 
 * ver.1 (2021/01/11) 公開
 * 
 */

/**
 * Fisher–Yates shuffle
 * @method
 * @param {Array} array Data to shuffle.
 * 
 */
function shuffle(array){
    var rnd = 0;
    var tmp = null;
    for (var i = array.length - 1; i > 0; i--) {
        rnd = Math.floor(Math.random() * (i + 1));
        tmp = array[i];
        array[i] = array[rnd];
        array[rnd] = tmp;
    }
}

/**
 * Create new quiz data.
 * @constructor
 * @classdesc This is one quiz class.
 * @param {Object} quiz One quiz data from "Quiz.json".
 * 
 */
class Quiz {
    constructor(quiz){
        this._quiz = quiz;
        this._answerCount = 0;
        this._shuffleAnswer = null;
        this.load();
        this.shuffleAnswer();
    }

    load() {
        if (!!$gameSystem._quizList && !!$gameSystem._quizList[this._quiz.id]) {
            var count = $gameSystem._quizList[this._quiz.id].answerCount;
            this._answerCount = !!count ? count : 0;
        }
    }

    save() {
        if (!$gameSystem._quizList) {
            $gameSystem._quizList = {};
        }
        if (!$gameSystem._quizList[this._quiz.id]) {
            $gameSystem._quizList[this._quiz.id] = {};
        }
        $gameSystem._quizList[this._quiz.id].answerCount = this._answerCount;
    }

    shuffleAnswer() {
        this._shuffleAnswer = [];
        this._shuffleAnswer.push(this._quiz.correct);
        this._quiz.wrong.forEach(answer => {
            this._shuffleAnswer.push(answer);
        }, this);
        shuffle(this._shuffleAnswer);
    }

    correctIndex() {
        return this._shuffleAnswer.indexOf(this._quiz.correct);
    }

    addAnswerCount(point) {
        this._answerCount += point;
    }

    resetAnswerCount() {
        this._answerCount = 0;
    }

    correct() {
        if (this._answerCount < 0) {
            this.resetAnswerCount();
        }
        this.addAnswerCount(1);
    }

    wrong(){
        if (this._answerCount > 0) {
            this.resetAnswerCount();
        }
        this.addAnswerCount(-1);
    }
}

/**
 * Create new quiz list data and shuffle.
 * @constructor
 * @classdesc This is a quiz list class.
 * @param {Object} dataQuiz quiz list from "Quiz.json".
 * 
 */
class QuizList {
    constructor(dataQuiz) {
        this._index = 0;
        this._quizList = [];
        dataQuiz.quizList.forEach(quiz => {
            this._quizList.push(new Quiz(quiz));
        }, this);
        shuffle(this._quizList);
    }

    /**
     * Get one quiz data.
     * @method
     * @returns one quiz data.
     * 
     */
    quiz() {
        return this._quizList[this._index];
    }

    addIndex() {
        this._index += 1;
    }

    correct() {
        this._quizList[this._index].correct();
        this._quizList[this._index].save();
    }

    wrong() {
        this._quizList[this._index].wrong();
        this._quizList[this._index].save();
    }
}

var quizList = null;
var quiz = null;

(function() {

'use strict';

DataManager.loadQuizData = function(chapter, section) {
    var filename = 'Quiz%1%2.json'.format(chapter.padZero(3), section.padZero(3));
    this.loadDataFile('$dataQuiz', filename);
};

//================================================
// Plugin Command

var KRD_Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
Game_Interpreter.prototype.pluginCommand = function(command, args) {
    KRD_Game_Interpreter_pluginCommand.call(this, command, args);

    switch (command) {
        case 'load':
            var chapter = Number(args[0]);
            var section = Number(args[1]);
            DataManager.loadQuizData(chapter, section);
            break;
        case 'newStage':
            quizList = new QuizList($dataQuiz);
            break;
        case 'quiz':
            quiz = quizList.quiz();
            break;
        case 'correct':
            quizList.correct();
            break;
        case 'wrong':
            quizList.wrong();
            break;
        case 'nextQuiz':
            quizList.addIndex();
            break;
    }
};

}());
